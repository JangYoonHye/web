<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>

<tr><td height=1 colspan=2 class=line></td></tr>

<tr>
<td height=30 width=60 nowrap align=center class=ver7>name</td>
<td height=30 width=100% style="padding-top:3;"><?=$face_image?><?=$name?></td>
</tr>

<tr><td height=1 colspan=2 class=line></td></tr>

<?=$hide_homepage_start?>
<tr>
<td height=30 width=60 nowrap align=center class=ver7>home</td>
<td height=30 width=100% class=ver7><?=$homepage?></td>
</tr>
<tr><td height=1 colspan=2 class=line></td></tr>
<?=$hide_homepage_end?>

<tr>
<td height=30 width=60 nowrap align=center class=ver7>subject</td>
<td height=30 width=100% style="padding-top:3;"><?=$subject?></td>
</tr>

<?=$hide_download1_start?>
<tr><td height=1 colspan=2 class=line></td></tr>
<tr>
<td height=30 width=60 nowrap align=center class=ver7>file 1</td>
<td height=30 width=100% class=ver7><?=$a_file_link1?><?=$file_name1?> (<?=$file_size1?>)</a></td>
</tr>
<?=$hide_download1_end?>

<?=$hide_download2_start?>
<tr><td height=1 colspan=2 class=line></td></tr>
<tr>
<td height=30 width=60 nowrap align=center class=ver7>file 2</td>
<td height=30 width=100% class=ver7><?=$a_file_link2?><?=$file_name2?> (<?=$file_size2?>)</a></td>
</tr>
<?=$hide_download2_end?>

<?=$hide_sitelink1_start?>
<tr><td height=1 colspan=2 class=line></td></tr>
<tr>
<td height=30 width=60 nowrap align=center class=ver7>link 1</td>
<td height=30 width=100% class=ver7><?=$sitelink1?></td>
</tr>
<?=$hide_sitelink1_end?>

<?=$hide_sitelink2_start?>
<tr><td height=1 colspan=2 class=line></td></tr>
<tr>
<td height=30 width=60 nowrap align=center class=ver7>link 2</td>
<td height=30 width=100% class=ver7><?=$sitelink2?></td>
</tr>
<?=$hide_sitelink2_end?>

<tr><td height=1 colspan=2 class=line></td></tr>
</table>

<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr>
<td style='padding:15 10 15 10;'>
<?=$upload_image1?>
<?=$upload_image2?>
<p><?=$memo?></p>
</td>
</tr>
</table>

<?=$hide_comment_start?> 
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>> 
<?=$hide_comment_end?>