<br><br><br><br>

<table align=center border=0 cellspacing=0 cellpadding=0 width=250>
<tr><td colspan=2 height=1 class=line></td></tr>

<tr><td colspan=2 height=20></td></tr>

<tr><td align=center colspan=2 class=ver7>member login</td></tr>

<tr><td colspan=2 height=10></td></tr>

<tr>
  <td align=right width=95 class=ver7>i . d&nbsp;&nbsp;</td>
  <td><input type=text name=user_id style="width:110;height:18;" class=input2></td>
</tr>

 <tr><td colspan=2 height=5></td></tr>

<tr>
  <td align=right width=95 class=ver7>pass&nbsp;&nbsp;</td>
  <td><input type=password name=password style="width:110;height:18;" class=input2> </td>
</tr>

<tr><td colspan=2 height=20></td></tr>

<tr><td colspan=2 height=1 class=line></td></tr>

 <tr><td colspan=2 height=10></td></tr>

<tr>
  <td align=center colspan=2>
  <input onfocus='this.blur()' type=submit value=' login ' align=center class=button>&nbsp;
<input onfocus='this.blur()' type=button value=' back '  align=center class=button onclick="history.go(-1)">
  </td>
</tr>
</table>

<br><br><br><br>