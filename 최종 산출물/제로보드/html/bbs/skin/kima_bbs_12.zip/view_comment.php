<tr>
<td style="padding:10;">
<table align=center cellpadding=0 cellspacing=0 width=95%>
<tr>
<td nowrap height=25 style='padding-top:3; padding-right:10;'><?=$c_face_image?> <?=$comment_name?></td>
<td width=100% align=left class=thm7 style='padding-top:2;'><?=$date=date("y-m-d",$c_data[reg_date])?>��<?=$a_del?><img src=<?=$dir?>/delete.gif border=0 align=absmiddle></a></td>
</tr>
<tr><td height=1 colspan=2 class=line></td></tr>
<tr><td height=7 colspan=2></td></tr>
<tr><td colspan=2 style='padding-bottom:5;'><?=nl2br($c_memo)?></td></tr>
<tr><td height=1 colspan=2 class=line></td></tr>
<tr><td height=5 colspan=2></td></tr>
</table>
</td>
</tr>