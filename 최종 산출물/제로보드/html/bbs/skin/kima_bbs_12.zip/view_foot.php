<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr><td colspan=2 height=20></td></tr>
<tr><td colspan=2 height=1 class=line></td></tr>
<tr>
<td align=left style="padding-top:7;" class=ver7>
<?=$a_list?>list</a>&nbsp;&nbsp;<?=$a_write?>write</a>
</td>

<td align=right style="padding-top:7;" class=ver7>
<?=$a_reply?>reply</a>&nbsp;&nbsp;<?=$a_modify?>modify</a>&nbsp;&nbsp;<?=$a_delete?>delete</a>
 </td>
</tr>
</table>

<br>


<?=$hide_prev_start?>
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr><td colspan=3 height=1 class=line></td></tr>
<tr>
<td height=30 width=40 nowrap align=center class=ver7>prev</td>
<td align=left style="padding-top:3;"><?=$a_prev?><?=$prev_subject?></a></td>
<td align=right style="padding-top:3;"><?=$prev_name?></td>
</tr>
</table>
<?=$hide_prev_end?>

<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr><td height=1 class=line></td></tr></table>

<?=$hide_next_start?>
<table border=0 cellspacing=0 cellpadding=0 width=<?=$width?>>
<tr>
<td height=30 width=40 nowrap align=center class=ver7>next</td>
<td align=left style='padding-top:3;'><?=$a_next?><?=$next_subject?></a></td>
<td align=right style='padding-top:3;'><?=$next_name?></td>
</tr>
<tr><td colspan=3 height=1 class=line></td></tr>
</table>
<?=$hide_next_end?>


<br>